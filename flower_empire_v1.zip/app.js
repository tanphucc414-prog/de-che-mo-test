const tg=window.Telegram?.WebApp; tg?.ready(); tg?.expand();

const FLOWERS=[
 {id:"sun",name:"Hướng dương",emoji:"🌻",grow:30,price:45,seed:12,rarity:"Thường"},
 {id:"tulip",name:"Tulip hồng",emoji:"🌷",grow:90,price:145,seed:38,rarity:"Hiếm"},
 {id:"rose",name:"Hoa hồng",emoji:"🌹",grow:180,price:320,seed:80,rarity:"Hiếm"},
 {id:"lav",name:"Oải hương",emoji:"💜",grow:300,price:620,seed:155,rarity:"Sử thi"},
 {id:"orchid",name:"Lan ánh trăng",emoji:"🌸",grow:900,price:2100,seed:420,rarity:"Huyền thoại"}
];

let state=JSON.parse(localStorage.getItem("flowerEmpire")||"null")||{
 coin:500,cash:0,level:1,exp:0,plots:Array(6).fill(null),inventory:{},orders:[],withdrawals:[]
};
function save(){localStorage.setItem("flowerEmpire",JSON.stringify(state))}
function fmt(n){return Number(n).toLocaleString("vi-VN")}
function toast(t){let x=document.getElementById("toast");x.textContent=t;x.classList.add("show");setTimeout(()=>x.classList.remove("show"),1800)}
function gainExp(n){state.exp+=n;while(state.exp>=state.level*250){state.exp-=state.level*250;state.level++;toast("🎉 Lên cấp "+state.level+"!")}save()}
function plant(i,id){
 const f=FLOWERS.find(x=>x.id===id); if(!f)return;
 if(state.plots[i])return toast("Ô đất đang có cây!");
 if(state.coin<f.seed)return toast("Không đủ xu để mua hạt!");
 state.coin-=f.seed; state.plots[i]={id,started:Date.now()}; gainExp(4); render(); toast("🌱 Đã gieo "+f.name)
}
function harvest(i){
 const p=state.plots[i],f=FLOWERS.find(x=>x.id===p.id), elapsed=(Date.now()-p.started)/1000;
 if(elapsed<f.grow)return toast("🌱 Hoa chưa nở đâu!");
 state.coin+=f.price; state.inventory[f.id]=(state.inventory[f.id]||0)+1;
 state.plots[i]=null;gainExp(12);save();render();toast("🌸 Thu hoạch +"+fmt(f.price)+" xu")
}
function garden(){
 let plots=state.plots.map((p,i)=>{
  if(!p)return `<div class="tile empty" onclick="openSeed(${i})"></div>`;
  let f=FLOWERS.find(x=>x.id===p.id), pct=Math.min(100,(Date.now()-p.started)/(f.grow*1000)*100);
  return `<div class="tile" onclick="harvest(${i})"><div class="plant">${f.emoji}</div><div class="plant-label">${pct>=100?"✨ Thu hoạch":f.name}</div><div class="progress"><i style="width:${pct}%"></i></div></div>`
 }).join("");
 return `<div class="content">
  <div class="balance"><div class="money coin"><small>🪙 Xu</small><strong>${fmt(state.coin)}</strong></div><div class="money cash"><small>💵 Tờ tiền</small><strong>${fmt(state.cash)} ₫</strong></div></div>
  <div class="hero"><h2>🌷 Khu vườn cấp ${state.level}</h2><p>Trồng hoa, mở rộng trang viên và xây dựng đế chế hoa của riêng bạn.</p></div>
  <div class="garden"><div class="section-title"><h3>🏡 Trang viên</h3><span>Chạm ô đất để gieo hạt</span></div><div class="plot">${plots}</div></div>
  <div class="section-title"><h3>🌱 Hạt giống nổi bật</h3><span>Kho: ${Object.values(state.inventory).reduce((a,b)=>a+b,0)}</span></div>
  <div class="cards">${FLOWERS.slice(0,4).map(f=>`<div class="card"><div class="flower-icon">${f.emoji}</div><h4>${f.name}</h4><div class="muted">${f.grow<60?f.grow+" giây":Math.round(f.grow/60)+" phút"} • bán ${fmt(f.price)} xu</div><button class="btn soft" onclick="quickPlant('${f.id}')">Gieo ngay • ${f.seed} xu</button></div>`).join("")}</div>
 </div>`
}
function quickPlant(id){let i=state.plots.findIndex(x=>!x);if(i<0)return toast("Hết ô đất trống!");plant(i,id)}
function openSeed(i){
 let cards=FLOWERS.map(f=>`<div class="order"><div class="emoji">${f.emoji}</div><div class="grow"><b>${f.name}</b><small class="muted">${f.rarity} • ${f.seed} xu</small></div><button class="btn" style="width:100px;margin:0" onclick="plant(${i},'${f.id}');closeModal()">Gieo</button></div>`).join("");
 showModal(`<div class="sheet"><h2>🌱 Chọn hạt giống</h2>${cards}<button class="btn close" onclick="closeModal()">Đóng</button></div>`)
}
function shop(){
 return `<div class="content"><div class="hero"><h2>🛒 Cửa hàng hạt giống</h2><p>Giống càng hiếm, chu kỳ càng dài và lợi nhuận càng lớn.</p></div><div class="section-title"><h3>Tất cả giống hoa</h3></div><div class="cards">${FLOWERS.map(f=>`<div class="card"><div class="flower-icon">${f.emoji}</div><h4>${f.name}</h4><div class="muted">${f.rarity} • ${Math.ceil(f.grow/60)} phút</div><div style="margin-top:7px">💰 Bán: <b>${fmt(f.price)} xu</b></div><button class="btn" onclick="quickBuy('${f.id}')">Mua hạt ${fmt(f.seed)} xu</button></div>`).join("")}</div></div>`
}
function quickBuy(id){let f=FLOWERS.find(x=>x.id===id);if(state.coin<f.seed)return toast("Không đủ xu");state.coin-=f.seed;state.inventory[id]=(state.inventory[id]||0)+1;save();toast("🌱 Đã mua hạt "+f.name);render()}
function orders(){
 return `<div class="content"><div class="hero"><h2>📦 Đơn hàng hoa</h2><p>Đóng bó hoa để kiếm thêm xu và EXP.</p></div><div class="section-title"><h3>Đơn hàng hôm nay</h3></div>
 ${FLOWERS.slice(0,4).map((f,k)=>{let need=2+k,have=state.inventory[f.id]||0;return `<div class="order"><div class="emoji">${f.emoji}</div><div class="grow"><b>Bó ${f.name}</b><div class="muted">${have}/${need} hoa • thưởng ${fmt(f.price*(k+2))} xu</div></div><button class="btn gold" style="width:90px;margin:0" ${have<need?"disabled":""} onclick="fulfill('${f.id}',${need},${f.price*(k+2)})">Giao</button></div>`}).join("")}
 </div>`
}
function fulfill(id,need,reward){if((state.inventory[id]||0)<need)return;state.inventory[id]-=need;state.coin+=reward;gainExp(20);save();render();toast("📦 Giao hàng thành công! +"+fmt(reward)+" xu")}
function wallet(){
 return `<div class="content"><div class="walletbox"><small>SỐ DƯ CÓ THỂ RÚT</small><h1>${fmt(state.cash)} ₫</h1><span>💵 Tờ tiền • tiền rút thực tế</span></div>
 <div class="rule"><b>🪙 Xu trong game</b><span class="muted">${fmt(state.coin)} xu — dùng để mua hạt và nâng cấp.</span></div>
 <div class="rule"><b>💵 Tờ tiền</b><span class="muted">Chỉ số dư đủ điều kiện mới chuyển sang số dư rút.</span></div>
 <button class="btn" onclick="withdraw()">💸 Yêu cầu rút tiền</button>
 <div class="section-title"><h3>🔐 Nguyên tắc an toàn</h3></div>
 <div class="rule"><span class="muted">Payout thật sẽ được kiểm soát ở backend/admin. Bản V1 này chưa kết nối cổng thanh toán và chưa bật AdsGram/Monetag.</span></div>
 </div>`
}
function withdraw(){showModal(`<div class="sheet"><h2>💸 Yêu cầu rút</h2><p class="muted">Bản demo: admin sẽ duyệt giao dịch ở backend sau khi hệ thống payout được kết nối.</p><input id="bank" class="input" placeholder="Ngân hàng"><input id="acc" class="input" placeholder="Số tài khoản"><input id="owner" class="input" placeholder="Tên chủ tài khoản"><input id="amount" class="input" type="number" placeholder="Số tiền (₫)"><button class="btn" onclick="submitWithdraw()">Gửi yêu cầu</button><button class="btn close" onclick="closeModal()">Hủy</button></div>`)}
function submitWithdraw(){let amount=+document.getElementById("amount").value;if(!amount||amount<=0)return toast("Nhập số tiền hợp lệ");state.withdrawals.unshift({bank:document.getElementById("bank").value,acc:document.getElementById("acc").value,owner:document.getElementById("owner").value,amount,status:"pending",time:new Date().toISOString()});save();closeModal();toast("📨 Đã gửi yêu cầu rút");}
function profile(){return `<div class="content"><div class="hero"><h2>👤 Người chơi</h2><p>Cấp ${state.level} • EXP ${state.exp}/${state.level*250}</p></div><div class="rule"><b>🌱 Thành tựu</b><span class="muted">Thu hoạch ${Object.values(state.inventory).reduce((a,b)=>a+b,0)} hoa trong kho.</span></div><div class="rule"><b>🔗 Referral</b><span class="muted">Hệ thống referral sẽ kết nối Telegram backend ở bản tiếp theo.</span></div></div>`}
function openProfile(){showModal(`<div class="sheet">${profile()}<button class="btn close" onclick="closeModal()">Đóng</button></div>`)}
function showModal(x){document.getElementById("modal").innerHTML=x;document.getElementById("modal").classList.remove("hidden")}
function closeModal(){document.getElementById("modal").classList.add("hidden")}
let tab="garden";
function render(){document.getElementById("screen").innerHTML=tab==="garden"?garden():tab==="shop"?shop():tab==="orders"?orders():wallet();document.querySelectorAll(".bottom button").forEach(b=>b.classList.toggle("active",b.dataset.tab===tab))}
document.querySelectorAll(".bottom button").forEach(b=>b.onclick=()=>{tab=b.dataset.tab;render()});
render();setInterval(()=>{if(tab==="garden")render()},1000);
