# Flower Empire V1

Telegram Mini App prototype: trồng hoa lâu dài, trang viên, hạt giống, thu hoạch, đơn hàng, xu và số dư tờ tiền.

## Chạy thử
Mở `index.html` bằng hosting HTTPS rồi mở trong Telegram Mini App.

## Lưu ý
- V1 hiện lưu dữ liệu gameplay bằng localStorage để test giao diện/gameplay.
- Payout thật, admin backend, Firebase/Cloudflare Worker, chống gian lận và xác minh Telegram chưa được nối.
- AdsGram/Monetag chưa tích hợp; đã để kiến trúc UI sẵn để cắm sau.
- Không nên coi số dư demo là tiền thật cho tới khi backend payout được triển khai và kiểm thử.

## File
- index.html
- style.css
- app.js
- assets/*.svg
